import React, { useState, useEffect } from "react";
import {
  FiStar,
  FiTrendingUp,
  FiGlobe,
  FiUsers,
  FiAward,
  FiHeart,
  FiCpu,
} from "react-icons/fi";
import "./Milestones.css";

const Milestones = () => {
  const [activeYearIndex, setActiveYearIndex] = useState(0);

  const milestones = [
    {
      year: "2019",
      title: "Foundation",
      description:
        "We began our journey in Bangalore with a small office and a global vision. By connecting with international clients through digital platforms, we built a strong foundation based on innovation, reliability, and trust.",
      icon: <FiStar />,
      color: "#522c72",
    },
    {
      year: "2020",
      title: "Headquarters",
      description:
        "During the COVID-19 pandemic, we expanded to London, establishing it as our global headquarters. This move strengthened our presence in the UK and focused our expertise on secure cloud solutions for regulated industries.",
      icon: <FiTrendingUp />,
      color: "#772b6a",
    },
    {
      year: "2021",
      title: "Multicloud",
      description:
        "We evolved into a full multi-cloud provider, working across Azure, AWS, and GCP. We also expanded into healthcare and banking with industry-focused solutions.",
      icon: <FiGlobe />,
      color: "#962964",
    },
    {
      year: "2023",
      title: "Collaboration",
      description:
        "With remote teams across India, the US, and the UK, we built a strong global collaboration model, enabling continuous innovation and 24/7 delivery support.",
      icon: <FiUsers />,
      color: "#ce2453",
    },
    {
      year: "2024",
      title: "Expansion",
      description:
        "We opened our US office, accelerating our AI-driven and multi-cloud capabilities while bringing us closer to clients and new markets.",
      icon: <FiAward />,
      color: "#dd5c54",
    },
    {
      year: "2025",
      title: "Scaling",
      description:
        "We expanded offshore and onshore operations with new offices in the US and Tamil Nadu, India, strengthening enterprise delivery, scalability, and Data & AI capabilities.",
      icon: <FiHeart />,
      color: "#e27d55",
    },
    {
      year: "2026",
      title: "Evolution",
      description:
        "We focused on strengthening global operations, enhancing AI and automation capabilities, and deepening enterprise partnerships. This year reflects smarter scaling, stronger execution, and measurable global impact.",
      icon: <FiCpu />,
      color: "#e79e57",
    },
  ];

  // Auto-play the timeline
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveYearIndex((prevIndex) => (prevIndex + 1) % milestones.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [milestones.length]);

  return (
    <section className="about-timeline-section reveal">
      <div className="about-container">
        <div className="about-section-header">
          <span className="about-label">Our Journey</span>
          <h2 className="about-gradient-text">Milestones that Define Us</h2>
          <p className="about-subhead">
            A decade of breaking barriers and setting new standards in cloud
            engineering and automation.
          </p>
        </div>

        <div className="timeline-side-menu-layout">
          <div className="timeline-menu-sidebar">
            {milestones.map((milestone, index) => (
              <button
                key={index}
                className={`timeline-menu-btn ${activeYearIndex === index ? "active" : ""}`}
                onClick={() => setActiveYearIndex(index)}
                style={{
                  "--theme-color": milestone.color,
                }}
              >
                <span
                  className="menu-btn-year"
                  style={{
                    color: activeYearIndex === index ? milestone.color : "",
                  }}
                >
                  {milestone.year}
                </span>
                <span className="menu-btn-title">{milestone.title}</span>
              </button>
            ))}
          </div>

          <div className="timeline-menu-content-area">
            <div
              className="timeline-content-card keyframe-slide-vertical"
              key={activeYearIndex}
              style={{ "--theme-color": milestones[activeYearIndex].color }}
            >
              <div
                className="content-card-bg-glow"
                style={{
                  background: `radial-gradient(circle at right, ${milestones[activeYearIndex].color}4D 0%, transparent 60%)`,
                }}
              ></div>
              <div className="content-card-year-watermark">
                {milestones[activeYearIndex].year}
              </div>
              <div
                className="content-card-icon"
                style={{
                  background: milestones[activeYearIndex].color,
                  boxShadow: `0 10px 30px ${milestones[activeYearIndex].color}80`,
                }}
              >
                {milestones[activeYearIndex].icon}
              </div>
              <h3>{milestones[activeYearIndex].title}</h3>
              <p>{milestones[activeYearIndex].description}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Milestones;
