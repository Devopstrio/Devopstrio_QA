import React from 'react';
import PropTypes from 'prop-types';
import './Pinboard.css';

/**
 * Pinboard - A dynamic process flow component with "pinned" cards and a curve path.
 * 
 * @param {Object} props
 * @param {string} props.pill - Small category label above the title
 * @param {string} props.title - Main title of the section
 * @param {string} props.subhead - Description text below the title
 * @param {Array} props.items - Array of objects { title, description }
 * @param {string} props.footerText - Text at the bottom of the flow
 */
const Pinboard = ({ 
  pill = "How we work", 
  title = "What Drives Us Forward", 
  subhead = "These core principles guide every decision we make and every relationship we build.",
  items = [],
  footerText = "Ready to be delivered!"
}) => {
  const stepTitles = ["Define", "Design", "Build", "Launch"];

  return (
    <section className="pinboard-section reveal">
      <div className="pinboard-container">
        <div className="pinboard-header">
          <span className="pinboard-pill">{pill}</span>
          <h2 className="pinboard-gradient-text">{title}</h2>
          <p className="pinboard-subhead">{subhead}</p>
        </div>

        <div className="pinboard-visual-container">
          {/* Background Grid Overlay */}
          <div className="pinboard-grid-bg"></div>
          
          {/* Dynamic Curve Path */}
          <div className="pinboard-curve-container">
            <svg className="pinboard-curve-svg" viewBox="0 0 1000 1300" preserveAspectRatio="none">
              <path 
                d="M800,80 C800,250 200,250 200,430 C200,600 800,600 800,830 C800,1030 150,1030 150,1230" 
                fill="none" 
                stroke="rgba(240, 13, 77, 0.6)" 
                strokeWidth="3" 
                strokeDasharray="12 12" 
              />
            </svg>
          </div>

          <div className="pinboard-items">
            {items.slice(0, 4).map((item, index) => (
              <div className={`pinboard-card step-${index + 1}`} key={index}>
                <div className="pinboard-card-hole"></div>
                <div className="pinboard-card-content">
                  <span className="pinboard-number">{`0${index + 1}`}</span>
                  <h3 className="pinboard-step-title">{stepTitles[index] || item.title}</h3>
                  <div className="pinboard-card-inner">
                    <p className="pinboard-desc">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
            
            <div className="pinboard-footer-text">
              {footerText}
              <div className="pinboard-arrow-icon">↘</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

Pinboard.propTypes = {
  pill: PropTypes.string,
  title: PropTypes.string,
  subhead: PropTypes.string,
  items: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string,
      description: PropTypes.string,
    })
  ),
  footerText: PropTypes.string,
};

export default Pinboard;
